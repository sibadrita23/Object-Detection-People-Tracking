# People_counting_basic
Download YOLO v3 weights [here](https://pjreddie.com/media/files/yolov3.weights) <br>

Test video [here](https://drive.google.com/file/d/17uVp-15sD-h5Y_WkbX1fl-Z8IPcAqA45/view?usp=sharing)

```
python counting_people.py --video D:/pycharmprojects/Counting-People/test.mp4
```
Output [video](https://drive.google.com/file/d/1ljOc76gY_0teYBgaWYHYqAFiu_eNgP3W/view?usp=sharing)

[Reference](https://github.com/Matskevichivan)
